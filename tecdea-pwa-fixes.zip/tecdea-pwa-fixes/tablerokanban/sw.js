const CACHE_NAME = 'kanban-pwa-2.33';

// Versión de la app: es el texto que sigue al prefijo de la caché
// ("kanban-pwa-"), p. ej. "2.32" con el esquema actual (major.minor) o
// "v32" con el esquema antiguo; se muestra tal cual en el chip.
// Se expone a las páginas a través del protocolo de mensajes GET_VERSION
// (ver listener 'message' al final de este archivo).
const APP_VERSION = (function () {
  const prefix = 'kanban-pwa-';
  if (CACHE_NAME.startsWith(prefix)) {
    return CACHE_NAME.slice(prefix.length) || CACHE_NAME;
  }
  return CACHE_NAME;
})();

const urlsToCache = [
  './',
  './index.html',
  './manifest.json',
  './icons/favicon.svg',
  './splash/splash-design.svg',
  './icons/icon-192x192.png',
  './icons/icon-512x512.png',
  './icons/icon-152x152.png',
  './js/main.js',
  './js/config.js',
  './js/utils.js',
  './js/state.js',
  './js/firebase-service.js',
  './js/tasks.js',
  './js/import-export.js',
  './js/pwa.js',
  './js/boards.js',
  './js/auth.js'
];

// Install event - cache core files
self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(function(cache) {
        console.log('Cache abierta');
        return cache.addAll(urlsToCache);
      })
      .catch(function(error) {
        // Si falla el precache, no bloqueamos la instalación del SW.
        // El fetch handler seguirá cacheando bajo demanda.
        console.error('Error al precachear:', error);
      })
  );
  self.skipWaiting();
});

// Activate event - clean old caches
self.addEventListener('activate', function(event) {
  event.waitUntil(
    caches.keys().then(function(cacheNames) {
      return Promise.all(
        cacheNames.map(function(cacheName) {
          // Filtrar por prefijo propio: caches.keys() es global al origen y
          // sin este filtro se borraban las cachés del portal y demás apps.
          if (cacheName.startsWith('kanban-pwa-') && cacheName !== CACHE_NAME) {
            console.log('Eliminando cache antigua:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Fetch event - Network first, fallback to cache.
//   - Solo se interceptan peticiones GET (POST/PUT etc. no son cacheables
//     y pueden lanzar error si se hace caches.match sobre ellas).
//   - Las navegaciones offline reciben index.html como fallback para que
//     la PWA siga funcionando sin red.
self.addEventListener('fetch', function(event) {
  // Ignorar peticiones que no sean http/https (como chrome-extension://)
  if (event.request.method !== 'GET' || !event.request.url.startsWith('http')) {
    return;
  }

  // Fallback de navegación: si la red falla, servir index.html cacheado
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request).catch(function() {
        return caches.match('./index.html');
      })
    );
    return;
  }

  event.respondWith(
    fetch(event.request)
      .then(function(response) {
        // Cachear solo respuestas válidas del mismo origen
        if (response && response.status === 200 && response.type === 'basic') {
          const responseClone = response.clone();
          caches.open(CACHE_NAME).then(function(cache) {
            cache.put(event.request, responseClone);
          });
        }
        return response;
      })
      .catch(function() {
        return caches.match(event.request);
      })
  );
});

// Message event - protocolo de consulta de versión.
// index.html pregunta con { type: 'GET_VERSION' } y este SW responde al
// cliente que la solicitó (event.source) con { type: 'APP_VERSION', ... }
// para que el chip de versión de la interfaz se actualice dinámicamente.
self.addEventListener('message', function(event) {
  if (!event.data || event.data.type !== 'GET_VERSION') {
    return;
  }
  if (event.source) {
    event.source.postMessage({
      type: 'APP_VERSION',
      version: APP_VERSION,
      cache: CACHE_NAME
    });
  }
});
