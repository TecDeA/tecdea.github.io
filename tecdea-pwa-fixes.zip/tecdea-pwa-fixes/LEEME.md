# Correcciones PWA — tecdea.github.io

Archivos corregidos para eliminar las interferencias entre las PWAs de los
subdirectorios y el portal. Cada carpeta corresponde a un repositorio de la
organización TecDeA y contiene **solo los archivos que hay que reemplazar**.

## Cómo subir los archivos

1. Entra en el repositorio de la app (p. ej. `github.com/TecDeA/tdvhex`).
2. Comprueba que estás en la rama que publica GitHub Pages (normalmente
   `main` o `gh-pages`; míralo en *Settings → Pages*).
3. *Add file → Upload files* y arrastra el/los archivos de la carpeta
   correspondiente **respetando la ruta** (p. ej. `sw.js` va en la raíz del
   repositorio de la app, junto al `index.html` actual).
4. *Commit changes* y espera a que termine el despliegue de Pages
   (pestaña *Actions* o el puntito junto al hash del commit).
5. Comprueba la versión desplegada abriendo la app en el navegador con
   el nombre de archivo en la URL (`.../sw.js?_=` + algo) o recargando
   la app dos veces.

> Consejo: si una app ya está instalada en tu móvil, tras subir el fix
> ábrela, recarga una o dos veces y vuelve a abrirla para que el nuevo
> service worker tome el control. No hace falta desinstalarla.

---

## 1. Correcciones CRÍTICAS de instalación (conflicto de scope con el portal)

### `tdvhex/`
| Archivo | Problema | Corrección |
|---|---|---|
| `manifest.json` | `start_url: "/"` sin `scope` ni `id` → reclamaba TODO el origen al instalarla: el icono abría el portal, competía por el scope `/` con el portal y su identidad (`/`) colisionaba con tdvkarnaugh | `id: "/tdvhex/"`, `start_url: "./index.html"`, `scope: "./"` |
| `sw.js` | En `activate` borraba **todas** las cachés del origen que no fueran la suya (dejaba sin offline al portal y al resto de apps) | Filtro por prefijo propio `tdvhex-` |

### `tdvkarnaugh/`
| Archivo | Problema | Corrección |
|---|---|---|
| `manifest.json` | Idéntico al de tdvhex | `id: "/tdvkarnaugh/"`, `start_url: "./index.html"`, `scope: "./"` |

*(Su `sw.js` ya filtraba bien por prefijo `logic-generator-`: no se toca.)*

### Portal (`tecdea.github.io`) — sin cambios
El `sw.js` del portal ya filtra correctamente por rutas propias
(`PORTAL_PATHS`, `/img/`, prefijo `tecdea-portal-`), por lo que **no hay que
tocarlo**. Con tdvhex y tdvkarnaugh corregidos desaparece el conflicto de
scope. El manifest del portal mantiene `scope: "/"` a propósito: si algún día
quieres una separación total, muévelo a `/portal-tecdea/` (su `id` ya apunta
ahí) con `scope: "/portal-tecdea/"`, pero es una decisión de diseño aparte.

---

## 2. Apps que NO se podían instalar (rutas 404 en GitHub Pages)

### `problemasean/`
| Archivo | Problema | Corrección |
|---|---|---|
| `manifest.json` | Todas las rutas apuntaban a `/ProblemasEAN/` (con mayúsculas): `start_url`, `scope`, 8 iconos y 3 shortcuts daban 404 y Chrome ni siquiera ofrecía instalar | Todo en relativo (`./`, `img/…`, `EAN04/index.html`…) + `id: "/problemasean/"` |

### `isustopra/`
| Archivo | Problema | Corrección |
|---|---|---|
| `manifest.json` | `start_url`, `scope` e iconos apuntaban a `/ISUStoPRA/` (404) | Rutas relativas + `id: "/isustopra/"` |
| `index.html` | `<link rel="manifest">`, `<link rel="icon">`, `apple-touch-icon` y `serviceWorker.register('/ISUStoPRA/sw.js')` daban 404 | Todas las referencias en relativo (`manifest.json`, `icons/…`, `./sw.js`) |

---

## 3. SWs que borraban las cachés de las demás apps (interferencia offline)

En un mismo origen, `caches.keys()` devuelve **todas** las cachés del dominio.
Estos service workers hacían `filter(c => c !== MI_CACHE)` y borraban lo
demás: cada vez que una de estas apps se actualizaba, el portal y las otras
apps perdían su caché offline. La corrección añade el filtro por prefijo
propio (el mismo patrón que ya usaban hooke, matricesdirac, numerosmetalicos, etc.):

| Carpeta | Archivo | Prefijo propio del filtro |
|---|---|---|
| `analisisbjt/` | `sw.js` | `bjt-analyzer-` |
| `byteantiguo/` | `service-worker.js` | `byte-` |
| `calificatec4/` | `sw.js` | `evaltec4-online-` |
| `clemasv2/` | `service-worker.js` | `clemas-v2-cache-` |
| `constantecatalan/` | `sw.js` | `catalan-g-` |
| `distancia2puntos/` | `sw.js` | `distmc-` |
| `ledemisorreceptor/` | `sw.js` | `led-remoto-` |
| `matrices/` | `sw.js` | `bestiario-` |
| `montajesbjt/` | `sw.js` | `calc-bjt-` |
| `notacionpolaca/` | `sw.js` | `notacion-polaca-` |
| `tablerokanban/` | `sw.js` | `kanban-pwa-` |
| `tdvhex/` | `sw.js` | `tdvhex-` (ya listada arriba) |
| `unidadpresentacionascensor/` | `sw.js` | `panel-leds-` |

En todos los casos el cambio es el mismo y está comentado en el propio
archivo: el filtro de `activate` pasa de `k !== CACHE_NAME` a
`k.startsWith('PREFIJO-') && k !== CACHE_NAME`.

---

## 4. SWs rotos por precache de rutas 404 (quedaban sin offline)

### `clemasv1/`
| Archivo | Problema | Corrección |
|---|---|---|
| `sw.js` | Precacheaba `/SimuladorClemas/*` (el directorio real es `/clemasv1/`): `addAll` fallaba y el SW nunca se activaba | Rutas relativas (`./index.html`, `./icons/…`), versión de caché subida a `v1.3`, `skipWaiting` y `activate` nuevo con filtro `simulador-clemas-` |

### `tec4evalinic/`
| Archivo | Problema | Corrección |
|---|---|---|
| `service-worker.js` | Precacheaba `/TEC4EvalInic/*` (404): `addAll` fallaba siempre | Rutas relativas, versión `v2.2`, caché resiliente (`Promise.allSettled` para que un CDN caído no aborte la instalación) y `activate` con filtro `evalinictec4-` |

### `sorteoalumnado/`
| Archivo | Problema | Corrección |
|---|---|---|
| `sw.js` | Acumulaba 5 fallos: ① **error de sintaxis** (falta una coma en el array `STATIC_ASSETS`) → el SW ni siquiera se registraba; ② precacheaba `/`, `/index.html` y `/manifest.json` **de la raíz del portal**; ③ iconos `/icons/*` inexistentes (404); ④ en `activate` borraba todas las cachés del origen; ⑤ el fallback offline devolvía `caches.match('/')` → **la portada del portal dentro de la app** | Reescritura completa: sintaxis corregida, todo en relativo (`./`, `./icons/…`), cachés renombradas a `sorteo-static-v6` / `sorteo-dynamic-v6`, borrado filtrado por `sorteo-` (+ limpieza de las legacy `static-v5`/`dynamic-v5`), fallback offline a `./index.html`, cabecera `accept` a prueba de null, y `CLEAR_CACHE` / notificaciones acotadas a la app |

---

## Comprobación después de subir

Para cada app corregida:
1. Abre `https://tecdea.github.io/<app>/` en Chrome (escritorio o Android).
2. DevTools → *Application*:
   - *Manifest*: `start_url` y `scope` deben apuntar a `https://tecdea.github.io/<app>/…` sin errores.
   - *Service workers*: *activated and running*, sin errores de instalación.
   - *Cache storage*: solo deben aparecer cachés con el prefijo propio de la app.
3. En el menú de los tres puntos debe aparecer «Instalar aplicación» y el
   icono instalado debe abrir la propia app (no el portal).
4. Prueba de no-regresión global: actualiza una app corregida y comprueba
   que la caché del portal (`tecdea-portal-v2.18`) y la de otras apps
   siguen intactas en *Cache storage*.

## Apps auditadas sin necesidad de cambios

arduinoacademy, autovaloresyautovectores, calculosean, cielocharlieplexing,
classroomtoapps, correlaciontec4, cursoarduino, diariotec4, distancia2puntoscuadrado,
evalcompesptec4, fraccionescontinuas, fraccionesequivalentes, funciongamma, hooke,
matricesdirac, numerosmetalicos, practicasab,
problemasedi, rubricas, rubricastecnov2, seguimientopra y el portal raíz.
