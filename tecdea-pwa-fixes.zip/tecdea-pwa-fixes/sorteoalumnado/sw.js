// ════════════════════════════════════════════════════════════
//  Service Worker — Sorteo Aleatorio de Nombres (corregido)
//  · Rutas relativas (antes apuntaban a la raíz del portal)
//  · Cachés con prefijo propio 'sorteo-' y borrado filtrado
//    (antes borraba las cachés de las demás apps del origen)
//  · Fallback offline a ./index.html (antes servía el portal)
// ════════════════════════════════════════════════════════════
const CACHE_NAME = 'sorteo-app-v1.1.1';
const STATIC_CACHE = 'sorteo-static-v6';
const DYNAMIC_CACHE = 'sorteo-dynamic-v6';
// Cachés antiguas (sin prefijo propio) que hay que retirar
const LEGACY_CACHES = ['static-v5', 'dynamic-v5'];

// Archivos a cachear (rutas relativas al directorio de la app)
const STATIC_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
  'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap',
  'https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js',
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js'
];

// Iconos (rutas relativas)
const ICONS = [
  './icons/icon-72.png',
  './icons/icon-96.png',
  './icons/icon-128.png',
  './icons/icon-144.png',
  './icons/icon-152.png',
  './icons/icon-192.png',
  './icons/icon-384.png',
  './icons/icon-512.png'
];

// Instalación del Service Worker
self.addEventListener('install', (event) => {
  console.log('[Service Worker] Instalando...');

  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then((cache) => {
        console.log('[Service Worker] Cacheando recursos estáticos');
        // Caché resiliente: cada URL de forma independiente para que un
        // recurso externo caído no aborte la instalación del SW.
        return Promise.allSettled(STATIC_ASSETS.map((u) => cache.add(u)));
      })
      .then(() => {
        console.log('[Service Worker] Instalación completada');
        return self.skipWaiting();
      })
  );
});

// Activación del Service Worker
self.addEventListener('activate', (event) => {
  console.log('[Service Worker] Activando...');

  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          // Eliminar SOLO cachés propias (prefijo 'sorteo-') y las legacy.
          // caches.keys() es global al origen: sin este filtro se borraban
          // las cachés del portal y del resto de apps.
          const esLegacy = LEGACY_CACHES.includes(cacheName);
          const esPropia = cacheName.startsWith('sorteo-');
          if (esLegacy || (esPropia && cacheName !== STATIC_CACHE && cacheName !== DYNAMIC_CACHE)) {
            console.log('[Service Worker] Eliminando caché antigua:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
    .then(() => {
      console.log('[Service Worker] Activación completada');
      return self.clients.claim();
    })
  );
});

// Estrategia de cache: Cache First, fallback a Network
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  const accept = event.request.headers.get('accept') || '';

  // No cachear solicitudes a APIs externas a menos que sea necesario
  if (event.request.url.includes('cdn.jsdelivr.net') ||
      event.request.url.includes('cdnjs.cloudflare.com') ||
      event.request.url.includes('fonts.googleapis.com')) {

    event.respondWith(
      caches.match(event.request)
        .then((cachedResponse) => {
          if (cachedResponse) {
            return cachedResponse;
          }

          return fetch(event.request)
            .then((response) => {
              // Cachear la respuesta para futuras peticiones
              return caches.open(DYNAMIC_CACHE)
                .then((cache) => {
                  cache.put(event.request, response.clone());
                  return response;
                });
            })
            .catch(() => {
              // Si falla la red y no está en caché, mostramos el shell local
              if (accept.includes('text/html')) {
                return caches.match('./index.html');
              }
            });
        })
    );
    return;
  }

  // Para peticiones de la propia app
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        if (response) {
          return response;
        }

        return fetch(event.request)
          .then((fetchResponse) => {
            // Solo cachear respuestas exitosas
            if (!fetchResponse || fetchResponse.status !== 200 || fetchResponse.type !== 'basic') {
              return fetchResponse;
            }

            const responseToCache = fetchResponse.clone();

            caches.open(DYNAMIC_CACHE)
              .then((cache) => {
                cache.put(event.request, responseToCache);
              });

            return fetchResponse;
          })
          .catch(() => {
            // Para peticiones de página, mostrar el shell de la app
            // (antes: caches.match('/') → devolvía la portada del portal)
            if (accept.includes('text/html')) {
              return caches.match('./index.html')
                .then((cachedResponse) => {
                  return cachedResponse || new Response('<h1>Estás offline</h1><p>La aplicación necesita conexión a internet para esta función.</p>', {
                    headers: { 'Content-Type': 'text/html' }
                  });
                });
            }
          });
      })
  );
});

// Manejar mensajes desde la aplicación
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }

  if (event.data && event.data.type === 'CLEAR_CACHE') {
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          // Solo borrar cachés propias, nunca las de otras apps
          if (cacheName.startsWith('sorteo-') || LEGACY_CACHES.includes(cacheName)) {
            return caches.delete(cacheName);
          }
        })
      );
    });
  }
});

// Manejar sync en background (para futuras funcionalidades)
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-data') {
    console.log('[Service Worker] Sincronizando datos en background...');
    // Aquí podrías sincronizar datos pendientes
  }
});

// Manejar push notifications (para futuras funcionalidades)
self.addEventListener('push', (event) => {
  const options = {
    body: event.data ? event.data.text() : '¡Nuevo sorteo disponible!',
    icon: './icons/icon-192.png',
    badge: './icons/icon-96.png',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    },
    actions: [
      {
        action: 'explore',
        title: 'Abrir aplicación',
        icon: './icons/icon-96.png'
      },
      {
        action: 'close',
        title: 'Cerrar',
        icon: './icons/icon-96.png'
      }
    ]
  };

  event.waitUntil(
    self.registration.showNotification('Organizador Aleatorio', options)
  );
});

self.addEventListener('notificationclick', (event) => {
  console.log('[Service Worker] Notificación clickeada');

  event.notification.close();

  if (event.action === 'explore') {
    // Abrir la aplicación (relativo al scope, no la raíz del portal)
    event.waitUntil(
      clients.openWindow('./')
    );
  }
});
