const CACHE_NAME = 'simulador-clemas-v1.3';
const urlsToCache = [
  './',
  './index.html',
  './style.css',
  './script.js',
  './manifest.json',
  './icons/icon-72x72.png',
  './icons/icon-152x152.png',
  './icons/icon-512x512.png',
  './clemas.jpg'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Cache abierto');
        return cache.addAll(urlsToCache);
      })
      .then(() => self.skipWaiting())
  );
});

// Activación: limpiar SOLO las cachés propias (prefijo 'simulador-clemas-').
// En un origen compartido caches.keys() devuelve TODAS las cachés del dominio:
// filtrar por prefijo evita borrar las cachés del portal y de las demás apps.
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys
          .filter(k => k.startsWith('simulador-clemas-') && k !== CACHE_NAME)
          .map(k => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Devuelve la respuesta en caché o realiza la petición
        if (response) {
          return response;
        }
        return fetch(event.request);
      }
    )
  );
});