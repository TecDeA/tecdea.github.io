// ── Versión de la aplicación (fuente única de verdad) ─────────────
// Cualquier cliente puede pedir la versión actual enviando al SW
// un mensaje { type: 'GET_VERSION' }. El SW responde con
// { type: 'VERSION', version: APP_VERSION }.
const APP_VERSION = '2.1.0';

// El nombre del caché incluye la versión para que un cambio de versión
// invalide automáticamente la caché anterior (en `activate` se borran
// las cachés cuyo nombre no coincide).
const CACHE_NAME = `tdvhex-${APP_VERSION}`;
const ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      // Filtrar por prefijo propio: caches.keys() es global al origen y
      // sin este filtro se borraban las cachés del portal y demás apps.
      Promise.all(names.filter(n => n.startsWith('tdvhex-') && n !== CACHE_NAME).map(n => caches.delete(n)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request).then((res) => {
        if (!res || res.status !== 200 || res.type !== 'basic') return res;
        const clone = res.clone();
        caches.open(CACHE_NAME).then(c => c.put(event.request, clone));
        return res;
      });
    }).catch(() => {
      if (event.request.mode === 'navigate') return caches.match('./index.html');
    })
  );
});

// ── Mensajería con la página ─────────────────────────────────────
// Permite que index.html pida la versión de la app de forma dinámica
// en vez de tenerla duplicada en el HTML.
self.addEventListener('message', (event) => {
  const data = event.data || {};
  if (data.type === 'GET_VERSION') {
    const reply = { type: 'VERSION', version: APP_VERSION };
    // event.source es el Client que envió el mensaje (cuando existe).
    if (event.source && typeof event.source.postMessage === 'function') {
      event.source.postMessage(reply);
    } else if (self.clients && self.clients.matchAll) {
      // Fallback: reenviar a todos los clientes controlados.
      self.clients.matchAll({ type: 'window' }).then((clients) => {
        clients.forEach((c) => c.postMessage(reply));
      });
    }
  }
});
